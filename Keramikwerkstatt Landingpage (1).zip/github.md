repo: bettiogian-cyber/-lpi
branch: main

## Last sync
date: 2026-09-02T00:00:00Z
Hinweis: Repository ist leer (kein Baum vorhanden), es wurde nichts importiert.

### Updated in this project
- Website des Restaurant Älpli (Start, Speisekarten, Öffnungszeiten, Über uns, Kontakt) als eine Design-Komponente
- Zusätzlich `index.html` als Kopie für statisches Hosting (GitHub Pages)

## Screen map
| Screen | Repo-Dateien |
| --- | --- |
| Restaurant Älpli (alle Reiter) | — (nicht aus Repo erzeugt) |
